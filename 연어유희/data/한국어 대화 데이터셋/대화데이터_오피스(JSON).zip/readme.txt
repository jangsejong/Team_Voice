Data pre-processing for AI hub upload


Data structure
- index
- domain (daily, email, schedule, meeting)
- user_utterance
- system_utterance


JSON structure
{
  "data":[
    {
      "index":0,
      "domain":"daily",
      "user_utterance":"",
      "system_utterance":""
    }
  ]
}

Data stats
- daily
  set: 5,320
  pair: 15,967
- task
  set: 4,882
  pair: 30,447

- total
  set: 10,202
  pair: 46,414
